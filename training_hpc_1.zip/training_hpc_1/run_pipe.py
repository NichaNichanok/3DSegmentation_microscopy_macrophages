import os
import json
import torch
import nibabel as nib
import numpy as np
import matplotlib.pyplot as plt

from monai.apps.auto3dseg import AutoRunner
from monai.apps.auto3dseg import DataAnalyzer, BundleGen
from monai.config import print_config
from monai.data import create_test_image_3d


def main():
    print_config()

    # Check if MPS is available, otherwise fall back to CPU
    device = torch.device("mps") if torch.backends.mps.is_available() else torch.device("cpu")
    print(f"Using device: {device}")

    datalist_file = {
        "testing": [
            {"image": "image_1.nii.gz"},
        ],
        "training": [
            {"fold": 0, "image": "image_2.nii.gz", "label": "label_2.nii.gz"},
            {"fold": 1, "image": "image_3.nii.gz", "label": "label_3.nii.gz"},
        ],
    }

    dataroot = "/Users/nicha/dev/auto3dseg/training/training_1_512"
    work_dir = "./auto3dseg"
    datalist_path = os.path.join(work_dir, "datalist.json")

    # Save datalist to JSON file
    os.makedirs(work_dir, exist_ok=True)
    with open(datalist_path, 'w') as f:
        json.dump(datalist_file, f, indent=4)

    input_config = {
        "name": "Macrophages3DSeg_01",  # optional, it is only for your own record
        "task": "segmentation",  # optional, it is only for your own record
        "modality": "MRI",  # Try Histopathology
        "datalist": datalist_path,  # required, now it is a path to the JSON file
        "dataroot": dataroot,  # required
    }

    # Run pipeline with minimal input
    runner = AutoRunner(
        work_dir=work_dir,
        input=input_config
    )
    runner.run()

if __name__ == '__main__':
    main()
    



"""# Run data analyzer
    analyser = DataAnalyzer(datalist_file, dataroot)
    datastat = analyser.get_all_case_stats()
    

    # Generate algorithm templates
    bundle_generator = BundleGen(
        algo_path="./auto3dseg",
        data_src_cfg_name=input_config,
        data_stats_filename=datastats_file,  # updated to correct variable
        algos="swinunetr",  # can specify specific algorithm
    )
    
    bundle_generator.generate("./auto3dseg", num_fold=2)

    # Run training
    runner = AutoRunner(
        work_dir="auto3dseg",
        input=input_config,
        analyze=False
        #device=device  # Pass the device here if applicable
    )"""